CONTRIBUTING
============

By contributing code to Chebfun, you agree to release it under the project's
[license][1] and moreover certify that you have the right to do so.

[1]: https://github.com/chebfun/chebfun/blob/development/LICENSE.txt
